# logic_pack

## Installation

- Locate the `.blend` file you are working with
- Create `Libraries` folder alongside your `.blend` file
- Clone this repository using `git clone https://github.com/armory3d/logic_pack` into `Libraries` folder
- Restart Blender and load your `.blend` file to register new nodes

## Creating new nodes

- http://armory3d.org/manual/#/dev/logicnodes
