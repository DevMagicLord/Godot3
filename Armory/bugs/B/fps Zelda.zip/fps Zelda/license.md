Using YBot rig by mixamo.com
