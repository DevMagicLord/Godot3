// Auto-generated
let project = new Project('Fzero');

project.addSources('Sources');
project.addLibrary("M:/3D/Armoryb28/Armory/armsdk/armory");
project.addLibrary("M:/3D/Armoryb28/Armory/armsdk/iron");
project.addLibrary("M:/3D/Armoryb28/Armory/armsdk/lib/haxebullet");
project.addAssets("M:/3D/Armoryb28/Armory/armsdk/lib/haxebullet/js/ammo/ammo.js", { notinlist: true });
project.addParameter('arm.node.Plqyer');
project.addParameter("--macro keep('arm.node.Plqyer')");
project.addParameter('armory.trait.physics.bullet.RigidBody');
project.addParameter("--macro keep('armory.trait.physics.bullet.RigidBody')");
project.addParameter('armory.trait.physics.bullet.PhysicsWorld');
project.addParameter("--macro keep('armory.trait.physics.bullet.PhysicsWorld')");
project.addShaders("build_Fzero/compiled/Shaders/*.glsl");
project.addAssets("build_Fzero/compiled/Assets/**", { notinlist: true });
project.addAssets("build_Fzero/compiled/Shaders/*.arm", { notinlist: true });
project.addAssets("M:/3D/Armoryb28/Armory/armsdk/armory/Assets/brdf.png", { notinlist: true });
project.addAssets("circuittexture.png", { notinlist: true });
project.addDefine('arm_deferred');
project.addDefine('arm_csm');
project.addDefine('arm_voxelgi');
project.addDefine('rp_hdr');
project.addDefine('rp_renderer=Deferred');
project.addDefine('rp_depthprepass');
project.addDefine('rp_shadowmap');
project.addDefine('rp_shadowmap_size=1024');
project.addDefine('rp_background=World');
project.addDefine('rp_render_to_texture');
project.addDefine('rp_compositornodes');
project.addDefine('rp_antialiasing=FXAA');
project.addDefine('rp_supersampling=1');
project.addDefine('rp_gi=Voxel AO');
project.addDefine('rp_voxelgi_resolution=128');
project.addDefine('rp_voxelgi_resolution_z=1.0');
project.addDefine('rp_ssgi=Off');
project.addDefine('arm_physics');
project.addDefine('arm_bullet');
project.addDefine('arm_shaderload');
project.addDefine('arm_soundcompress');
project.addDefine('arm_skin');
project.addDefine('arm_particles_gpu');
project.addDefine('arm_particles');
project.addDefine('arm_fast');


resolve(project);
